//
//  Modo02View.swift
//  Aula05
//
//  Created by Turma01-3 on 26/08/24.
//

import SwiftUI

struct Modo02View: View {
    @State private var name: String = ""
    var body: some View {
        NavigationStack {
            ZStack {
                Color.gray
                VStack {
                    Text("Modo 1")
                        .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                        .foregroundColor(.white)
                    TextField("name: ", text: $name)
                        .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                        .foregroundColor(.white)
                        .frame(width: 200, height: 100)
                        .background(Color.pink)
                        .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                        .foregroundColor(.white)
                    Text("Bem vindo, \(name)")
                        .frame(width: 200, height: 100)
                        .background(Color.pink)
                        .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                        .foregroundColor(.white)
                    NavigationLink(destination: Modo02SecundView(nameReceived: name)) {
                        Text("Acessar Tela")
                            .frame(width: 150, height: 50)
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(10.0)
                    }
                }
            }
            .ignoresSafeArea()
        }
    }
}

#Preview {
    Modo02View()
}
