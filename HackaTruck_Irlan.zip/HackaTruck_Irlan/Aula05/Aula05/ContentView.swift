//
//  ContentView.swift
//  Aula05
//
//  Created by Turma01-3 on 26/08/24.
//

import SwiftUI
struct SheetView: View {
    @Environment(\.dismiss) var toBack
    var body: some View {
        ZStack {
            Color.gray
            VStack {
                Text("\n")
                Text("Nome: Irlan\nSobrenome: Barros")
                    .frame(width: 300, height: 150)
                    .background(Color.pink)
                    .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                    .foregroundColor(.white)
                Spacer()
                Button("Voltar") {
                    toBack()
                }
                .frame(width: 100, height: 50)
                .background(Color.blue)
                .foregroundColor(.white)
                Text("\n")
            }
        }
        .ignoresSafeArea()
    }
}

struct ContentView: View {
    @State private var showingSheet = false
    var body: some View {
        NavigationStack {
            Image("logo1")
                .resizable()
                .scaledToFit()
                .frame(width: 395)
                .background(Color.gray)
            ZStack {
                Color.gray
                VStack {
                    NavigationLink(destination: Modo01View()) {
                        Text("Modo 1")
                            .frame(width: 200, height: 100)
                            .background(Color.pink)
                            .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                            .foregroundColor(.white)
                    }
                    NavigationLink(destination: Modo02View()) {
                        Text("Modo 2")
                            .frame(width: 200, height: 100)
                            .background(Color.pink)
                            .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                            .foregroundColor(.white)
                    }
                    Button("Modo 3") {
                        showingSheet.toggle()
                    }
                    .frame(width: 200, height: 100)
                    .background(Color.pink)
                    .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                    .foregroundColor(.white)
                    .sheet(isPresented: $showingSheet) {
                        SheetView()
                    }
                }
            }
            .ignoresSafeArea()
        }
    }
}

#Preview {
    ContentView()
}
