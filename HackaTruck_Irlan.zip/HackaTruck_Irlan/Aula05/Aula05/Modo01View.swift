//
//  Modo01View.swift
//  Aula05
//
//  Created by Turma01-3 on 26/08/24.
//

import SwiftUI

struct Modo01View: View {
    var body: some View {
        ZStack {
            Color.gray
            Text("Nome: Irlan\nSobrenome: Barros")
                .frame(width: 300, height: 150)
                .background(Color.pink)
                .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                .foregroundColor(.white)
        }
        .ignoresSafeArea()
    }
}

#Preview {
    Modo01View()
}
