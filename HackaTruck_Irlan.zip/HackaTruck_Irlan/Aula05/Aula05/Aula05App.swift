//
//  Aula05App.swift
//  Aula05
//
//  Created by Turma01-3 on 26/08/24.
//

import SwiftUI

@main
struct Aula05App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
