//
//  Modo02SecundView.swift
//  Aula05
//
//  Created by Turma01-3 on 26/08/24.
//

import SwiftUI

struct Modo02SecundView: View {
    
    @State var nameReceived: String = ""
    var body: some View {
        ZStack {
            Color.gray
            VStack {
                Text("Volte,\n \(nameReceived)")
                    .frame(width: 200, height: 100)
                    .background(Color.pink)
                    .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                    .foregroundColor(.white)
            }
        }
        .ignoresSafeArea()
    }
}

#Preview {
    Modo02SecundView()
}
