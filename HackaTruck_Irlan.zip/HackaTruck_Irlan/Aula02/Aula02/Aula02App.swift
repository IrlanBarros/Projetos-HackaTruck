//
//  Aula02App.swift
//  Aula02
//
//  Created by Turma01-3 on 22/08/24.
//

import SwiftUI

@main
struct Aula02App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
