//
//  ContentView.swift
//  Aula02
//
//  Created by Turma01-3 on 22/08/24.
//

import SwiftUI

struct ContentView: View {
    @State private var name: String = ""
    @State private var showingAlert = false
    
    var body: some View {
        VStack {
            ZStack {
                Image("spfc3")
                    .resizable()
                    .opacity(0.8)
                Image("truck")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 250, height: 180)
                VStack {
                    Text("\n")
                    HStack {
                        Text(" Bem vindo, ")
                            .font(.system(size: 40))
                            .foregroundColor(.white)
                        Spacer()
                    }
                    TextField("  Seu nome: ", text: $name)
                        .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                        .foregroundColor(.white)
                    Spacer()
                    
                    Button("Entrar") {
                        showingAlert = true
                    }
                    .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                    .foregroundColor(.white)
                    .frame(width: 150, height: 50)
                    .background(Color.blue)
                    .alert(isPresented: $showingAlert) {
                        Alert(title: Text("Alerta!"), message: Text("Está pronto para o desafio do Optimus Prime Tricolor? Hehehe"), dismissButton: .default(Text("Vamos lá!")))
                    }
                }
            }
        }
        .ignoresSafeArea()
    }
}

#Preview {
    ContentView()
}
