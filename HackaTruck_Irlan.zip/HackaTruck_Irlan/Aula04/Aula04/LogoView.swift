//
//  LogoView.swift
//  Aula04
//
//  Created by Turma01-3 on 26/08/24.
//

import SwiftUI

struct LogoView: View {
    var body: some View {
        ZStack {
            Image("94anos")
                .resizable()
            VStack {
                Spacer()
                Text("")
                    .frame(width: 400, height: 88)
                    .background(Color.white)
            }
        }
        .ignoresSafeArea()
    }
}

#Preview {
    LogoView()
}
