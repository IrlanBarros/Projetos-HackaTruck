//
//  TitlesView.swift
//  Aula04
//
//  Created by Turma01-3 on 26/08/24.
//

import SwiftUI

struct TitlesView: View {
    var body: some View {
        ZStack {
            Image("spfc1")
                .resizable()
            Image("trofeus")
                .resizable()
                .scaledToFit()
                .frame(width: 430)
            VStack {
                Spacer()
                Text("")
                    .frame(width: 400, height: 88)
                    .background(Color.white)
            }
        }
        .ignoresSafeArea()
    }
}

#Preview {
    TitlesView()
}
