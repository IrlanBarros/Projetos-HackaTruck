//
//  ContentView.swift
//  Aula04
//
//  Created by Turma01-3 on 26/08/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            HistoryView()
                .tabItem {
                    Label("History", systemImage: "clock.arrow.2.circlepath")
                }
            TitlesView()
                .tabItem {
                    Label("Titles", systemImage: "trophy.circle")
                }
            LogoView()
                .tabItem {
                    Label("Logo", systemImage: "shield.righthalf.filled")
                }
            IdolsView()
                .tabItem {
                    Label("Idols", systemImage: "list.bullet")
                }
        }
    }
}

#Preview {
    ContentView()
}
