//
//  IdolsView.swift
//  Aula04
//
//  Created by Turma01-3 on 26/08/24.
//

import SwiftUI

struct IdolsView: View {
    var body: some View {
        ZStack {
            VStack {
                NavigationView {
                    List() {
                        Text("Telê Santana")
                        Text("Rogério Ceni")
                        Text("Serginho Chulapa")
                        Text("Luís Fabiano")
                        Text("Kaká")
                        Text("Raí")
                        Text("Leônidas")
                        Text("Zetti")
                        Text("Lugano")
                        Text("Careca, Muller")
                        Text("Dário Pereira")
                        Text("Hernanes")
                        Text("Cafu")
                    }
                    .navigationTitle("Ídolos do São Paulo FC")
                }
                Spacer()
                Text("")
                    .frame(width: 400, height: 88)
                    .background(Color.white)
            }
        }
    }
}

#Preview {
    IdolsView()
}
