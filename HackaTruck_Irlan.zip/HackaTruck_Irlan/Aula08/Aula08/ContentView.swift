//
//  ContentView.swift
//  Aula08
//
//  Created by Turma01-03 on 30/08/24.
//

import SwiftUI

struct ContentView: View {
    @StateObject var viewModel = ViewModel()
    var body: some View {
        ScrollView{
            VStack{
                ForEach(viewModel.chars){ p in
                    VStack{
                        HStack{
                            Text(p.name!)
                            Spacer()
                            Text(p.actor!)
                        }
                    }
                }
            }
            .onAppear() {
                viewModel.fetch()
            }
        }
    }
}

#Preview {
    ContentView()
}
