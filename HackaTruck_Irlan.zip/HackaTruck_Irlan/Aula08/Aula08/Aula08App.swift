//
//  Aula08App.swift
//  Aula08
//
//  Created by Turma01-3 on 30/08/24.
//

import SwiftUI

@main
struct Aula08App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
