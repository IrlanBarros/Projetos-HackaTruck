//
//  ContentView1.swift
//  Aula01
//
//  Created by Turma01-3 on 21/08/24.
//

import SwiftUI

struct ContentView1: View {
    var body: some View {
        VStack {
            Text("A HISTÓRIA DO SPFC")
                .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                .foregroundColor(.white)
                .frame(width: 500)
                .background(Color.red)
            Text("São Paulo Futebol Clube. O tricolor paulista surgiu através da fusão de dois antigos clubes: o Paulistano, grande campeão no início do século XX e a Associação Atlética das Palmeiras, que se uniram em 1930 dando origem ao Clube Athlético São Paulo ou São Paulo da Floresta, como muitos o chamavam. No seu segundo ano de existência, o clube se consagrou campeão paulista. O São Paulo já era um gigante do futebol local, só que nem mesmo o clube imaginava onde iria chegar. Em 1935, o clube teve uma nova refundação. Isso ocorreu devido a uma crise política dentro da instituição. Alguns dirigentes não estavam contentes com a situação do futebol no país, tomando a atitude de sair do futebol e se unir com o Clube Regatas Tietê. Só que o futebol no tricolor resistiu, e em 4 de junho de 1935 alguns sócios refundaram o que foi chamado de Clube Atlético São Paulo, tornando-se posteriormente o grande São Paulo Futebol Clube. Surge então um gigante no futebol, com a tradição de colecionar títulos. É, essa camisa pesa, amigos, e como diz o próprio hino: Dentre os grandes és o primeiro!")
                .font(.headline)
                .foregroundColor(.white)
                .multilineTextAlignment(.center)
                .frame(height: 540)
                .background(Color.black)
            Spacer()
            HStack {
                Image("spfc")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 200)
                    .cornerRadius(500)
                VStack {
                    Text("São Paulo FC")
                        .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                        .foregroundColor(.red)
                    Text("É o melhor")
                        .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                        .foregroundColor(.white)
                        .frame(width: 150)
                        .background(Color.black)
                    Text("De todo Brasil!")
                        .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                        .foregroundColor(.black)
                }
            }
        }
    }
}

#Preview {
    ContentView1()
}
