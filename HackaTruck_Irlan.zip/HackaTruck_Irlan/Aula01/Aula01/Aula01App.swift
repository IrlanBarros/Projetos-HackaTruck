//
//  Aula01App.swift
//  Aula01
//
//  Created by Turma01-3 on 21/08/24.
//

import SwiftUI

@main
struct Aula01App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
