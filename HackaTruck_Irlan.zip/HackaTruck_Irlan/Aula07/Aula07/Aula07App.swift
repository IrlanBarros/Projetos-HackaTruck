//
//  Aula07App.swift
//  Aula07
//
//  Created by Turma01-3 on 29/08/24.
//

import SwiftUI

@main
struct Aula07App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
