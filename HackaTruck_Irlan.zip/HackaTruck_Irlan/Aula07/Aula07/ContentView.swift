//
//  ContentView.swift
//  Desafio maps
//
//  Created by Turma02-28 on 29/08/24.
//

import SwiftUI
import MapKit
import Foundation

struct Location: Identifiable{
    let id = UUID()
    let name: String
    let coordinate: CLLocationCoordinate2D
    let flag: String
    let description: String
}
var arraymapa = [
    Location(name: "Brasil", coordinate: CLLocationCoordinate2D(latitude: -15.803731, longitude: -47.89), flag:
                "https://upload.wikimedia.org/wikipedia/commons/thumb/0/05/Flag_of_Brazil.svg/250px-Flag_of_Brazil.svg.png",
             description:
                "O Brasil, um vasto país sul-americano, estende-se da Bacia Amazônica, no norte, até os vinhedos e as gigantescas Cataratas do Iguaçu, no sul. O Rio de Janeiro, simbolizado pela sua estátua de 38 metros de altura do Cristo Redentor, situada no topo do Corcovado, é famoso pelas movimentadas praias de Copacabana e Ipanema, bem como pelo imenso e animado Carnaval, com desfiles de carros alegóricos, fantasias extravagantes e samba."
            ),
    
    Location(name: "Ceará", coordinate: CLLocationCoordinate2D(latitude: -3.71839,longitude: -38.5434), flag: "https://upload.wikimedia.org/wikipedia/commons/thumb/2/2e/Bandeira_do_Ceará.svg/1200px-Bandeira_do_Ceará.svg.png", description: "O Estado do Ceará fica na região Nordeste do Brasil e tem uma área total de 148.886,308 km². Ele faz divisa com os estados de Pernambuco, Rio Grande do Norte, Paraíba e Piauí. É banhado pelo oceano Atlântico e tem 573 quilômetros de praias."),
    Location(name: "Barbalha", coordinate: CLLocationCoordinate2D(latitude: -7.30551,longitude: -39.3025), flag: "https://upload.wikimedia.org/wikipedia/commons/b/bb/Bandeira_de_Barbalha_-_Ceará.JPG", description: "Barbalha é um município brasileiro do estado do Ceará. Localiza-se na Região Metropolitana do Cariri, Mesorregião do Sul Cearense, a 504 quilômetros da capital Fortaleza pela BR-122. Ocupa a 7ª colocação no estado em IDH geral, a 9ª em IDH-Educação e a 4ª em IDH-Longevidade.")]


struct ContentView: View {
    @State private var position = MapCameraPosition.region(MKCoordinateRegion(center:  CLLocationCoordinate2D(latitude:-7.777796 , longitude:-39.930052 ), span: MKCoordinateSpan(latitudeDelta: 1, longitudeDelta: 1)))
    
    @State private var locations = arraymapa[0]
    @State private var showingSheet: Bool = false
    var body: some View {
        ZStack{
            VStack{
                VStack {
                    ZStack{
                        Color(.white)
                            .opacity(0.6)
                            .ignoresSafeArea()
                    }
                    VStack{
                        Text("Word map")
                            .font(.title)
                        Text(locations.name)
                    }
                }
                .frame(height: 100)
                
                Map(position: $position){
                    Annotation("",  coordinate: locations.coordinate){
                        Image(systemName: "signpost.right.fill")
                            .foregroundColor(.black)
                            .background(.white)
                            .font(.title)
                            .cornerRadius(3.0)
                            .onTapGesture {
                                showingSheet.toggle()
                            }
                            .sheet(isPresented: $showingSheet) {
                                VStack{
                                    Text(locations.name)
                                        .font(.title)
                                        .fontWeight(.bold)
                                        .padding()
                                    AsyncImage(url: URL(string: locations.flag)){
                                        Image in Image
                                            .resizable().frame(width: 360, height:240)
                                    } placeholder:{
                                        
                                    }
                                    Text(locations.description)
                                        .padding()
                                }
                            }
                    }
                }
                .ignoresSafeArea()
                
                
                Spacer()
                HStack{
                    ForEach(arraymapa) { location in
                        Button(action: {
                            locations = location
                            position = MapCameraPosition.region(MKCoordinateRegion(center:  location.coordinate, span: MKCoordinateSpan(latitudeDelta: 1, longitudeDelta: 1)))
                        }
                        ){
                            AsyncImage(url: URL(string: location.flag)){
                                Image in Image
                                    .resizable()
                                    .frame(width: 120, height: 80)
                                
                            }placeholder: {
                                Color.yellow
                            }
                        }
                    }
                    
                }
                .padding()
            }
            
            
        }
    }
}

#Preview {
    ContentView()
}
