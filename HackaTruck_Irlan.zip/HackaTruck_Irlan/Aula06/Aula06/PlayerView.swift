//
//  PlayerView.swift
//  Aula06
//
//  Created by Turma01-3 on 27/08/24.
//

import SwiftUI

struct PlayerView: View {
    @State var song: Song
    //    @State var idReceived: Int = 0
    //    @State var nameReceived: String = ""
    //    @State var artistReceived: String = ""
    //    @State var capaReceived: String = ""
    var body: some View {
        NavigationStack {
            ZStack {
                LinearGradient(colors: [.red, .black], startPoint: .top, endPoint: .bottom)
                    .ignoresSafeArea()
                VStack {
                    AsyncImage(url: URL(string: song.capa))
                    { image in
                        image.resizable()
                    } placeholder: {
                        ProgressView()
                    }
                    .frame(width: 230, height: 200)
                    Text("\(song.name)")
                        .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                        .foregroundColor(.white)
                    Text("\(song.artist)")
                        .foregroundColor(.white)
                    Text("\n\n\n\n\n")
                    
                    HStack {
                        Image(systemName: "shuffle")
                            .resizable()
                            .frame(width: 30, height: 30)
                            .foregroundColor(.white)
                        Text("     ")
                        Image(systemName: "backward.end.fill")
                            .resizable()
                            .frame(width: 30, height: 30)
                            .foregroundColor(.white)
                        Text("          ")
                        Image(systemName: "play.fill")
                            .resizable()
                            .frame(width: 50, height: 50)
                            .foregroundColor(.white)
                        Text("        ")
                        Image(systemName: "forward.end.fill")
                            .resizable()
                            .frame(width: 30, height: 30)
                            .foregroundColor(.white)
                        Text("     ")
                        Image(systemName: "repeat")
                            .resizable()
                            .frame(width: 30, height: 30)
                            .foregroundColor(.white)
                    }
                }
            }
        }
    }
}

#Preview {
    PlayerView(song: Song(id: 0, name: "", artist: "", capa: " "))
}
