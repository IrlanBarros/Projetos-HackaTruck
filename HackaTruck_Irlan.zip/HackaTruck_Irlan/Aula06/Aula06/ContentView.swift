//
//  ContentView.swift
//  Aula06
//
//  Created by Turma01-3 on 27/08/24.
//

struct Song : Identifiable {
    var id: Int
    var name: String
    var artist: String
    var capa: String
}

import SwiftUI

struct ContentView: View {
    @State var arrayMusicas = [
        Song(id: 1, name:"Hino do São Paulo FC", artist: "Banda Galera Campeã", capa: "https://i1.sndcdn.com/artworks-000013604433-0kebur-t500x500.jpg"),
        Song(id: 2, name: "Numb Encore", artist: "Linkin Park", capa: "https://upload.wikimedia.org/wikipedia/pt/d/d1/Jay-Z_and_Linkin_Park_-_Numb_Encore_CD_cover.jpg")
    ]
    var body: some View {
        NavigationStack {
            ZStack {
                LinearGradient(colors: [.red, .black], startPoint: .top, endPoint: .bottom)
                    .ignoresSafeArea()
                VStack {
                    ScrollView{
                        Image("spfc")
                            .resizable()
                            .frame(width: 230, height: 200)
                        HStack {
                            Text("  TricolorFM")
                                .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                                .foregroundColor(.white)
                            Spacer()
                        }
                        HStack {
                            Text("")
                            Image("spfc")
                                .resizable()
                                .frame(width: 30, height: 30)
                            Text("TrikasSong")
                                .foregroundColor(.white)
                            Spacer()
                        }
                        ForEach(0..<8) {
                            i in
                            ForEach(arrayMusicas) { musica in
                                NavigationLink(destination: PlayerView(song: musica)){
                                    HStack {
                                        Text("")
                                        AsyncImage(url: URL(string: musica.capa)) { image in
                                            image.resizable()
                                        } placeholder: {
                                            ProgressView()
                                        }
                                        .frame(width: 50, height: 50)
                                        VStack {
                                            Text(musica.name)
                                                .foregroundColor(.white)
                                            Text(musica.artist)
                                                .foregroundColor(.white)
                                        }
                                        Spacer()
                                        Image(systemName: "ellipsis")
                                            .foregroundColor(.white)
                                        Text("")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

#Preview {
    ContentView()
}
