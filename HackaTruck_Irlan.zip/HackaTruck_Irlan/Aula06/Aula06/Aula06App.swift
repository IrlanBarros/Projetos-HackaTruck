//
//  Aula06App.swift
//  Aula06
//
//  Created by Turma01-3 on 27/08/24.
//

import SwiftUI

@main
struct Aula06App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
