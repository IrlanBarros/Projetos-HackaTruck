//
//  Aula03App.swift
//  Aula03
//
//  Created by Turma01-3 on 23/08/24.
//

import SwiftUI

@main
struct Aula03App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
