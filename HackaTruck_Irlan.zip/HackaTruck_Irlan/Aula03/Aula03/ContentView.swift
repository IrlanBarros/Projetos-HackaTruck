//
//  ContentView.swift
//  Aula03
//
//  Created by Turma01-3 on 23/08/24.
//

import SwiftUI

struct ContentView: View {
    @State private var altura = ""
    @State private var peso = ""
    @State private var resul = 0.0
    @State private var altura1 = 0.0
    @State private var peso1 = 0.0
    @State private var viewColor = ""
    @State private var status = ""
    
    var body: some View {
        VStack {
            ZStack {
                Image("spfc3")
                    .resizable()
                VStack {
                    Text("\n\n")
                    HStack{
                        Text("Calculadora IMC")
                            .frame(width: 260)
                            .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                            .foregroundColor(.white)
                            .background(Color.black)
                        Spacer()
                    }
                    Text("\n\n\n")
                    TextField("Peso: ", text: $peso)
                        .frame(width: 350)
                        .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                        .background(Color.white)
                        .cornerRadius(5.0)
                    TextField("Altura: ", text: $altura)
                        .frame(width: 350)
                        .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                        .background(Color.white)
                        .cornerRadius(5.0)
                    Text("")
                    Button(action: {
                        altura1 = Double(altura) ?? 0.0
                        peso1 = Double(peso) ?? 0.0
                        
                        resul = peso1 / (pow(altura1,2) )
                        if (resul < 18.5) {
                            status = "Baixo peso"
                            viewColor = "Baixo peso"
                        } else if (resul >= 18.5 && resul < 25) {
                            status = "Normal"
                            viewColor = "Normal"
                        } else if (resul >= 25 && resul < 30) {
                            status = "Sobrepeso"
                            viewColor = "Sobrepeso"
                        } else if (resul > 30) {
                            status = "Obesidade"
                            viewColor = "Obesidade"
                        }
                        
                    }) {
                        Text("Calcular")
                            .frame(width: 150, height: 50)
                            .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                            .foregroundColor(.white)
                            .background(Color.blue)
                            .cornerRadius(8.0)
                    }
                    Text("\n")
                        Text("\(status)")
                            .frame(width: 350, height: 180)
                            .background(Color(viewColor))
                            .foregroundColor(.white)
                            .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                        Text("\n")
                        Image("tabela-IMC")
                            .resizable()
                    
                }
            }
        }
        
        .ignoresSafeArea()
    }
}

#Preview {
    ContentView()
}
